#define VER_EKIT_VER                    0x01010000
#define VER_PROJECT                     0x01010000

#define COM_SAME                        1

#define VER_FILEVERSION                 1,2,1,0
#define VER_FILEVERSION_STR             "1,2,1,0"

#define VER_PRODUCTVERSION              1,2,1,0
#define VER_PRODUCTVERSION_STR          "1.20T01"

